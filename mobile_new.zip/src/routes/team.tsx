import { createFileRoute } from "@tanstack/react-router";
import { UserPlus, ShieldCheck, Languages, Wifi } from "lucide-react";
import { AppShell, Panel, PanelRow, Tag } from "@/components/kala/shell";
import { staff, merchant, products } from "@/data/kalasangam";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Team & Master Verification — Kalasangam" },
      {
        name: "description",
        content:
          "Invite staff sub-accounts to capture products while the master artisan verifies every listing before export.",
      },
      { property: "og:title", content: "Team & Master Verification — Kalasangam" },
      {
        property: "og:description",
        content: "Assisted working with the artisan as the single point of truth.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TeamPage,
});

function TeamPage() {
  const pending = products.filter((p) => p.status !== "verified").length;

  return (
    <AppShell title="Team" subtitle={`${merchant.name} · master account`}>
      <Panel title="Merchant">
        <PanelRow>
          <span className="grid size-11 shrink-0 place-items-center rounded-full bg-primary font-mono text-xs text-primary-foreground">
            {merchant.initials}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{merchant.name}</p>
            <p className="truncate text-xs text-muted-foreground">
              {merchant.craft} · {merchant.village}
            </p>
          </div>
          <Tag tone="primary">Master</Tag>
        </PanelRow>
        <PanelRow>
          <ShieldCheck className="size-4 shrink-0 text-success" />
          <span className="min-w-0 flex-1 truncate text-sm">Verification queue</span>
          <Tag tone={pending ? "warning" : "success"}>{pending} pending</Tag>
        </PanelRow>
      </Panel>

      <Panel title="Staff sub-accounts">
        {staff.map((s) => (
          <PanelRow key={s.id}>
            <span className="grid size-10 shrink-0 place-items-center rounded-full bg-muted font-mono text-[11px]">
              {s.initials}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{s.name}</p>
              <p className="truncate text-xs text-muted-foreground">{s.role}</p>
            </div>
            <Tag>{s.drafts} drafts</Tag>
          </PanelRow>
        ))}
        <button className="panel-row hairline text-primary">
          <UserPlus className="size-4 shrink-0" />
          <span className="text-sm font-medium">Invite staff</span>
        </button>
      </Panel>

      <Panel title="Preferences">
        <PanelRow>
          <Languages className="size-4 shrink-0 text-muted-foreground" />
          <span className="min-w-0 flex-1 truncate text-sm">App language</span>
          <span className="shrink-0 text-sm text-muted-foreground">{merchant.language}</span>
        </PanelRow>
        <PanelRow>
          <Wifi className="size-4 shrink-0 text-muted-foreground" />
          <span className="min-w-0 flex-1 truncate text-sm">Low-connectivity mode</span>
          <Tag tone="success">On</Tag>
        </PanelRow>
      </Panel>
    </AppShell>
  );
}
