import { createFileRoute, Link } from "@tanstack/react-router";
import { Mic, ArrowUpRight, CheckCircle2, Clock3, MapPin, Upload } from "lucide-react";
import { AppShell, Panel, PanelRow, Tag } from "@/components/kala/shell";
import { merchant, products, events, docSteps } from "@/data/kalasangam";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Kalasangam — Voice-First Business Manager for Artisans" },
      {
        name: "description",
        content:
          "Kalasangam helps artisans catalog crafts by voice, price them transparently, track formalization and find nearby melas.",
      },
      { property: "og:title", content: "Kalasangam — Voice-First Business Manager for Artisans" },
      {
        property: "og:description",
        content: "Capture, price, formalize and export your craft catalog — all by voice.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const pending = products.filter((p) => p.status === "pending").length;
  const verified = products.filter((p) => p.status === "verified").length;
  const doneDocs = docSteps.filter((d) => d.status === "Active" || d.status === "Registered").length;

  return (
    <AppShell title="Kalasangam" subtitle={`${merchant.name} · ${merchant.village}`}>
      <Link
        to="/capture"
        className="panel flex items-center gap-4 bg-primary p-4 text-primary-foreground"
      >
        <span className="grid size-12 shrink-0 place-items-center rounded-full bg-primary-foreground/15">
          <Mic className="size-5" />
        </span>
        <span className="min-w-0">
          <span className="block font-display text-lg leading-tight">Add product by voice</span>
          <span className="block text-sm opacity-80">Speak in {merchant.language}</span>
        </span>
        <ArrowUpRight className="ml-auto size-5 shrink-0 opacity-80" />
      </Link>

      <div className="grid grid-cols-3 gap-3">
        {[
          { k: "Verified", v: verified },
          { k: "To verify", v: pending },
          { k: "Docs done", v: `${doneDocs}/5` },
        ].map((s) => (
          <div key={s.k} className="panel p-3">
            <p className="font-display text-2xl">{s.v}</p>
            <p className="panel-label mt-0.5 truncate">{s.k}</p>
          </div>
        ))}
      </div>

      <Panel
        title="Needs your verification"
        action={
          <Link to="/catalog" className="font-mono text-[11px] uppercase tracking-wider text-primary">
            All
          </Link>
        }
      >
        {products
          .filter((p) => p.status !== "verified")
          .map((p) => (
            <PanelRow key={p.id}>
              <img
                src={p.image}
                alt={p.name}
                loading="lazy"
                className="size-11 shrink-0 rounded-lg object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{p.name}</p>
                <p className="truncate text-xs text-muted-foreground">by {p.capturedBy}</p>
              </div>
              <Tag tone={p.exceptions.length ? "warning" : "muted"}>
                {p.exceptions.length ? `${p.exceptions.length} issue` : "Ready"}
              </Tag>
            </PanelRow>
          ))}
      </Panel>

      <Panel title="Next steps">
        <PanelRow>
          <Clock3 className="size-4 shrink-0 text-primary" />
          <span className="min-w-0 flex-1 truncate text-sm">Finish PAN application</span>
          <Link to="/ready" className="panel-label shrink-0 text-primary">
            Open
          </Link>
        </PanelRow>
        <PanelRow>
          <Upload className="size-4 shrink-0 text-accent" />
          <span className="min-w-0 flex-1 truncate text-sm">3 fields missing for GeM package</span>
          <Link to="/export" className="panel-label shrink-0 text-primary">
            Fix
          </Link>
        </PanelRow>
        <PanelRow>
          <CheckCircle2 className="size-4 shrink-0 text-success" />
          <span className="min-w-0 flex-1 truncate text-sm">ONDC export prepared</span>
          <Tag tone="success">Prepared</Tag>
        </PanelRow>
      </Panel>

      <Panel
        title="Selling nearby"
        action={
          <Link to="/discover" className="font-mono text-[11px] uppercase tracking-wider text-primary">
            Map
          </Link>
        }
      >
        {events.slice(0, 2).map((e) => (
          <PanelRow key={e.id}>
            <MapPin className="size-4 shrink-0 text-muted-foreground" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{e.name}</p>
              <p className="truncate text-xs text-muted-foreground">
                {e.date} · {e.distance}
              </p>
            </div>
            <Tag tone="accent">{e.tag}</Tag>
          </PanelRow>
        ))}
      </Panel>
    </AppShell>
  );
}
