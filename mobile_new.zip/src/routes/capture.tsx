import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Camera, Mic, Sparkles, Volume2, Check } from "lucide-react";
import { AppShell, Panel, PanelRow, Tag } from "@/components/kala/shell";
import { captureSteps, priceBreakdown, merchant } from "@/data/kalasangam";

export const Route = createFileRoute("/capture")({
  head: () => ({
    meta: [
      { title: "Voice Capture Studio — Kalasangam" },
      {
        name: "description",
        content:
          "Photograph a craft, enhance it on device, describe it by voice and let AI draft a multilingual catalog listing with a transparent price.",
      },
      { property: "og:title", content: "Voice Capture Studio — Kalasangam" },
      {
        property: "og:description",
        content: "Photo plus voice becomes a ready-to-verify product listing.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CapturePage,
});

function CapturePage() {
  const [step, setStep] = useState(1);
  const [recording, setRecording] = useState(false);
  const total = priceBreakdown.reduce((a, b) => a + b.value, 0);

  return (
    <AppShell title="Capture" subtitle={`Speaking in ${merchant.language}`}>
      <Panel title="Step 1 · Real photo">
        <div className="relative">
          <img
            src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=1000&q=70&auto=format&fit=crop"
            alt="Captured Kalamkari wall hanging on a clean background"
            className="aspect-[4/3] w-full object-cover"
          />
          <span className="absolute bottom-3 left-3 rounded-full bg-background/90 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.12em]">
            Original kept
          </span>
        </div>
        <div className="hairline grid grid-cols-2">
          <button className="flex items-center justify-center gap-2 py-3 text-sm font-medium">
            <Camera className="size-4" /> Retake
          </button>
          <button className="flex items-center justify-center gap-2 border-l border-border py-3 text-sm font-medium text-primary">
            <Sparkles className="size-4" /> Enhanced
          </button>
        </div>
      </Panel>

      <Panel title="Step 2 · Describe by voice">
        <div className="flex flex-col items-center gap-3 p-6">
          <button
            onClick={() => {
              setRecording((r) => !r);
              setStep(4);
            }}
            className={`grid size-24 place-items-center rounded-full transition-transform active:scale-95 ${
              recording ? "animate-pulse bg-destructive text-destructive-foreground" : "bg-primary text-primary-foreground"
            }`}
            aria-label="Record description"
          >
            <Mic className="size-9" />
          </button>
          <p className="text-center text-sm text-muted-foreground">
            {recording ? "Listening… speak naturally" : "Tap and speak about your product"}
          </p>
          <div className="flex h-8 items-end gap-1">
            {[6, 14, 22, 10, 26, 18, 8, 20, 12, 24, 9, 16].map((h, i) => (
              <span
                key={i}
                className="w-1.5 rounded-full bg-primary/40"
                style={{ height: recording ? h : 6 }}
              />
            ))}
          </div>
        </div>
        <div className="hairline bg-muted/50 px-4 py-3">
          <p className="panel-label">Transcript · Telugu → English</p>
          <p className="mt-1 text-sm">
            “This is a hand-painted Kalamkari wall hanging, cotton, natural dyes, took me two weeks.”
          </p>
        </div>
      </Panel>

      <Panel title="Step 3 · AI draft listing">
        <PanelRow>
          <span className="panel-label w-24 shrink-0">Title</span>
          <span className="min-w-0 flex-1 text-sm">Hand-painted Kalamkari cotton wall hanging</span>
        </PanelRow>
        <PanelRow>
          <span className="panel-label w-24 shrink-0">Category</span>
          <span className="min-w-0 flex-1 text-sm">Home décor › Textile art</span>
        </PanelRow>
        <PanelRow>
          <span className="panel-label w-24 shrink-0">Materials</span>
          <span className="min-w-0 flex-1 text-sm">Cotton, natural vegetable dyes</span>
        </PanelRow>
        <PanelRow>
          <span className="panel-label w-24 shrink-0">Keywords</span>
          <span className="min-w-0 flex-1 text-sm">kalamkari, pedana, handmade, wall art</span>
        </PanelRow>
        <button className="panel-row hairline text-primary">
          <Volume2 className="size-4 shrink-0" />
          <span className="text-sm font-medium">Play back in Telugu</span>
        </button>
      </Panel>

      <Panel title="Step 4 · Transparent price">
        {priceBreakdown.map((b) => (
          <PanelRow key={b.label}>
            <span className="min-w-0 flex-1 truncate text-sm">{b.label}</span>
            <span className="shrink-0 font-mono text-sm">₹{b.value}</span>
          </PanelRow>
        ))}
        <div className="hairline flex items-center gap-3 bg-muted/50 px-4 py-3">
          <span className="min-w-0 flex-1">
            <span className="panel-label block">Suggested range</span>
            <span className="font-display text-xl">
              ₹{Math.round(total * 0.94)} – ₹{Math.round(total * 1.15)}
            </span>
          </span>
          <Tag tone="success">High confidence</Tag>
        </div>
      </Panel>

      <Panel title="Progress">
        {captureSteps.map((s) => (
          <PanelRow key={s.id}>
            <span
              className={`grid size-6 shrink-0 place-items-center rounded-full font-mono text-[11px] ${
                s.id <= step ? "bg-success text-success-foreground" : "bg-muted text-muted-foreground"
              }`}
            >
              {s.id <= step ? <Check className="size-3.5" /> : s.id}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-medium">{s.title}</span>
              <span className="block truncate text-xs text-muted-foreground">{s.detail}</span>
            </span>
          </PanelRow>
        ))}
      </Panel>

      <button
        onClick={() => setStep(5)}
        className="w-full rounded-xl bg-primary py-3.5 text-sm font-semibold text-primary-foreground active:opacity-90"
      >
        Confirm & save listing
      </button>
    </AppShell>
  );
}
